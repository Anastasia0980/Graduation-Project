<template>
  <div class='page'>
    <AppTopbar
      :logged-in='true'
      :user-name='teacherName'
      current-role='teacher'
      active-nav='home'
      @platform-click='goTaskHall'
      @user-click='goTaskHall'
      @switch-role='switchRole'
      @logout='logout'
    />

    <div class='layout'>
      <TeacherSidebar active-menu='environment-manage' />

      <main class='content-area'>
        <div class='page-header'>
          <h2>环境管理</h2>
        </div>

        <div class='card'>
          <div class='card-title'>新建多人对战环境</div>

          <div class='form-grid'>
            <div class='form-item'>
              <label>环境名称</label>
              <input v-model='createForm.name' type='text' placeholder='例如：PettingZoo Boxing 对战环境' />
            </div>

            <div class='form-item'>
              <label>环境编码</label>
              <input v-model='createForm.code' type='text' placeholder='例如：boxing_v2' />
            </div>

            <div class='form-item'>
              <label>是否启用 GPU</label>
              <select v-model='createForm.isGpu'>
                <option :value='false'>否</option>
                <option :value='true'>是</option>
              </select>
            </div>

            <div class='form-item'>
              <label>CUDA 设备号</label>
              <input v-model='createForm.cudaDevice' type='text' placeholder='如 0，可留空' />
            </div>

            <div class='form-item full-width'>
              <label>requirements.txt</label>
              <div class='upload-row'>
                <button class='upload-btn' type='button' @click='triggerFileInput("requirementsInput")'>选择 requirements.txt</button>
                <span class='upload-text'>{{ requirementsFileName }}</span>
                <input
                  ref='requirementsInput'
                  class='hidden-file-input'
                  type='file'
                  accept='.txt'
                  @change='handleFileChange($event, "requirements")'
                />
              </div>
            </div>

            <div class='form-item full-width'>
              <label>对战测评脚本</label>
              <div class='upload-row'>
                <button class='upload-btn' type='button' @click='triggerFileInput("scriptInput")'>选择 Python 脚本</button>
                <span class='upload-text'>{{ scriptFileName }}</span>
                <input
                  ref='scriptInput'
                  class='hidden-file-input'
                  type='file'
                  accept='.py'
                  @change='handleFileChange($event, "script")'
                />
              </div>
            </div>
          </div>

          <div class='action-bar'>
            <button class='primary-btn' :disabled='submitting' @click='handleCreate'>{{ submitting ? '创建中...' : '创建环境' }}</button>
          </div>
        </div>

        <div class='card section-space'>
          <div class='card-title'>环境列表</div>

          <div v-if='loading' class='empty-box'>正在加载环境列表...</div>
          <div v-else-if='envList.length === 0' class='empty-box'>当前暂无已创建环境。</div>
          <div v-else class='table-wrap'>
            <table class='table'>
              <thead>
                <tr>
                  <th>环境名称</th>
                  <th>环境编码</th>
                  <th>状态</th>
                  <th>Conda 环境名</th>
                  <th>Python 路径</th>
                  <th>GPU</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for='item in envList' :key='item.id'>
                  <td>{{ item.name }}</td>
                  <td>{{ item.code }}</td>
                  <td>
                    <span class='status-tag' :class='statusClass(item.status)'>{{ formatStatus(item.status) }}</span>
                  </td>
                  <td>{{ item.condaEnvName || '--' }}</td>
                  <td class='path-cell'>{{ item.pythonPath || '--' }}</td>
                  <td>{{ item.isGpu ? `是${item.cudaDevice ? `（${item.cudaDevice}）` : ''}` : '否' }}</td>
                  <td>
                    <button class='mini-btn' type='button' @click='showLog(item)'>查看日志</button>

                    <button
                      v-if='canDisable(item)'
                      class='mini-btn danger-btn'
                      type='button'
                      @click='disableEnvironment(item)'
                    >停用</button>

                    <button
                      v-if='canDelete(item)'
                      class='mini-btn delete-btn'
                      type='button'
                      @click='deleteEnvironment(item)'
                    >删除</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div v-if='logDialogVisible' class='dialog-mask' @click.self='closeLogDialog'>
          <div class='dialog-card'>
            <div class='dialog-title'>安装日志 - {{ activeLogTitle }}</div>
            <pre class='log-box'>{{ activeLogContent }}</pre>
            <div class='dialog-actions'>
              <button class='primary-btn' type='button' @click='closeLogDialog'>关闭</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script>
import { ElMessage, ElMessageBox } from 'element-plus'
import AppTopbar from '../components/AppTopbar.vue'
import TeacherSidebar from '../components/TeacherSidebar.vue'

const API_BASE = (process.env.VUE_APP_API_BASE && process.env.VUE_APP_API_BASE.trim()) ||
  (typeof window !== 'undefined'
    ? `${window.location.protocol}//${window.location.hostname}:8080`
    : 'http://localhost:8080')

export default {
  name: 'TeacherEnvironmentManageView',
  components: {
    AppTopbar,
    TeacherSidebar
  },
  data () {
    return {
      teacherName: localStorage.getItem('auth_name') || '教师',
      loading: false,
      submitting: false,
      envList: [],
      requirementsFile: null,
      scriptFile: null,
      requirementsFileName: '当前未选择文件',
      scriptFileName: '当前未选择文件',
      createForm: {
        name: '',
        code: '',
        isGpu: false,
        cudaDevice: ''
      },
      logDialogVisible: false,
      activeLogTitle: '',
      activeLogContent: ''
    }
  },
  created () {
    this.loadEnvironmentList()
  },
  methods: {
    tokenHeader () {
      const token = localStorage.getItem('auth_token')
      return token ? { Authorization: `Bearer ${token}` } : {}
    },
    async loadEnvironmentList () {
      this.loading = true
      try {
        const response = await fetch(`${API_BASE}/battle-environments`, {
          method: 'GET',
          headers: this.tokenHeader()
        })
        const result = await response.json()
        if (!response.ok || result.code !== 0) {
          throw new Error(result.message || '环境列表加载失败')
        }
        this.envList = Array.isArray(result.data) ? result.data : []
      } catch (error) {
        this.envList = []
        ElMessage.error(error.message || '环境列表加载失败')
      } finally {
        this.loading = false
      }
    },
    triggerFileInput (refName) {
      const input = this.$refs[refName]
      if (input) {
        input.click()
      }
    },
    handleFileChange (event, type) {
      const file = event.target.files && event.target.files[0]
      if (type === 'requirements') {
        this.requirementsFile = file || null
        this.requirementsFileName = file ? file.name : '当前未选择文件'
      } else {
        this.scriptFile = file || null
        this.scriptFileName = file ? file.name : '当前未选择文件'
      }
    },
    validateCreateForm () {
      if (!this.createForm.name.trim()) {
        ElMessage.warning('请输入环境名称')
        return false
      }
      if (!this.createForm.code.trim()) {
        ElMessage.warning('请输入环境编码')
        return false
      }
      if (!this.requirementsFile) {
        ElMessage.warning('请上传 requirements.txt')
        return false
      }
      if (!this.scriptFile) {
        ElMessage.warning('请上传对战测评脚本')
        return false
      }
      return true
    },
    async handleCreate () {
      if (!this.validateCreateForm()) {
        return
      }
      this.submitting = true
      try {
        const formData = new FormData()
        formData.append('name', this.createForm.name.trim())
        formData.append('code', this.createForm.code.trim())
        formData.append('isGpu', this.createForm.isGpu)
        formData.append('cudaDevice', this.createForm.cudaDevice || '')
        formData.append('requirements', this.requirementsFile)
        formData.append('script', this.scriptFile)

        const response = await fetch(`${API_BASE}/battle-environments`, {
          method: 'POST',
          headers: this.tokenHeader(),
          body: formData
        })
        const result = await response.json()
        if (!response.ok || result.code !== 0) {
          throw new Error(result.message || '环境创建失败')
        }

        ElMessage.success('环境创建请求已提交，可在列表中查看安装状态')
        this.resetCreateForm()
        await this.loadEnvironmentList()
      } catch (error) {
        ElMessage.error(error.message || '环境创建失败')
      } finally {
        this.submitting = false
      }
    },
    resetCreateForm () {
      this.createForm = {
        name: '',
        code: '',
        isGpu: false,
        cudaDevice: ''
      }
      this.requirementsFile = null
      this.scriptFile = null
      this.requirementsFileName = '当前未选择文件'
      this.scriptFileName = '当前未选择文件'
      if (this.$refs.requirementsInput) {
        this.$refs.requirementsInput.value = ''
      }
      if (this.$refs.scriptInput) {
        this.$refs.scriptInput.value = ''
      }
    },
    showLog (item) {
      this.activeLogTitle = item.name || item.code
      this.activeLogContent = item.installLog || '暂无日志'
      this.logDialogVisible = true
    },
    closeLogDialog () {
      this.logDialogVisible = false
      this.activeLogTitle = ''
      this.activeLogContent = ''
    },
    canDisable (item) {
      return item && item.status === 'READY'
    },
    canDelete (item) {
      if (!item) {
        return false
      }
      return item.status === 'READY' || item.status === 'DISABLED' || item.status === 'FAILED'
    },
    async deleteEnvironment (item) {
      try {
        await ElMessageBox.confirm(
          `确认删除环境“${item.name || item.code}”吗？这将删除其 Conda 环境及已上传文件。`,
          '第一次确认',
          {
            confirmButtonText: '继续删除',
            cancelButtonText: '取消',
            type: 'warning'
          }
        )

        await ElMessageBox.confirm(
          '请再次确认：删除后该环境将变为“已删除”状态，且不再可用。',
          '第二次确认',
          {
            confirmButtonText: '确认删除',
            cancelButtonText: '取消',
            type: 'warning'
          }
        )

        const response = await fetch(`${API_BASE}/battle-environments/${item.id}`, {
          method: 'DELETE',
          headers: this.tokenHeader()
        })
        const result = await response.json()
        if (!response.ok || result.code !== 0) {
          throw new Error(result.message || '删除失败')
        }
        ElMessage.success('环境已删除')
        await this.loadEnvironmentList()
      } catch (error) {
        if (error === 'cancel' || error === 'close') {
          return
        }
        ElMessage.error(error.message || '删除失败')
      }
    },
    formatStatus (status) {
      const map = {
        CREATING: '创建中',
        READY: '可用',
        FAILED: '失败',
        DISABLED: '已停用',
        DELETED: '已删除'
      }
      return map[status] || status || '--'
    },
    statusClass (status) {
      return {
        creating: status === 'CREATING',
        ready: status === 'READY',
        failed: status === 'FAILED',
        disabled: status === 'DISABLED',
        deleted: status === 'DELETED'
      }
    },
    goTaskHall () {
      this.$router.push('/teacher/hall')
    },
    switchRole () {
      sessionStorage.removeItem('mock_logged_out_view')
      localStorage.setItem('mock_login_role', 'student')
      this.$router.push({ path: '/', query: { tab: 'open' } })
    },
    logout () {
      sessionStorage.setItem('mock_logged_out_view', 'true')
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.page {
  min-height: 100vh;
  background: #f5f7fa;
  font-family: 'Microsoft YaHei', 'PingFang SC', Arial, sans-serif;
  color: #303133;
}

.layout {
  display: flex;
  min-height: calc(100vh - 64px);
}

.content-area {
  flex: 1;
  padding: 20px;
}

.page-header {
  margin-bottom: 18px;
}

.page-header h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #1f2d3d;
}

.card {
  background: #ffffff;
  border: 1px solid #dcdfe6;
  border-radius: 8px;
  padding: 20px;
}

.section-space {
  margin-top: 18px;
}

.card-title {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 16px;
  color: #1f2d3d;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}

.form-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-item.full-width {
  grid-column: 1 / -1;
}

.form-item label {
  font-size: 14px;
  font-weight: 700;
  color: #303133;
}

.form-item input,
.form-item select {
  height: 40px;
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  padding: 0 12px;
  font-size: 14px;
  color: #303133;
  outline: none;
  background: #fff;
}

.upload-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.hidden-file-input {
  display: none;
}

.upload-btn,
.primary-btn,
.mini-btn {
  border: 1px solid #1F4E8C;
  background: #1F4E8C;
  color: #fff;
  border-radius: 6px;
  cursor: pointer;
}

.upload-btn,
.primary-btn {
  height: 40px;
  padding: 0 18px;
}

.mini-btn {
  height: 32px;
  padding: 0 12px;
  margin-right: 8px;
}

.danger-btn {
  background: #f56c6c;
  border-color: #f56c6c;
}

.delete-btn {
  background: #909399;
  border-color: #909399;
}

.upload-text {
  font-size: 13px;
  color: #606266;
}

.action-bar {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}

.empty-box {
  min-height: 120px;
  border: 1px dashed #dcdfe6;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #909399;
  font-size: 14px;
  background: #fafafa;
  text-align: center;
  padding: 20px;
}

.table-wrap {
  overflow-x: auto;
}

.table {
  width: 100%;
  border-collapse: collapse;
}

.table th,
.table td {
  border-bottom: 1px solid #ebeef5;
  padding: 12px 10px;
  text-align: left;
  font-size: 14px;
  vertical-align: top;
}

.table th {
  color: #606266;
  font-weight: 600;
  background: #fafafa;
}

.path-cell {
  max-width: 260px;
  word-break: break-all;
  color: #606266;
}

.status-tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 72px;
  height: 28px;
  border-radius: 14px;
  padding: 0 10px;
  font-size: 12px;
  font-weight: 600;
  border: 1px solid transparent;
}

.status-tag.creating {
  color: #e6a23c;
  background: #fdf6ec;
  border-color: #f5dab1;
}

.status-tag.ready {
  color: #67c23a;
  background: #f0f9eb;
  border-color: #c2e7b0;
}

.status-tag.failed {
  color: #f56c6c;
  background: #fef0f0;
  border-color: #f3c2c2;
}

.status-tag.disabled {
  color: #909399;
  background: #f4f4f5;
  border-color: #d3d4d6;
}

.status-tag.deleted {
  color: #909399;
  background: #fafafa;
  border-color: #e4e7ed;
}

.dialog-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
}

.dialog-card {
  width: min(860px, 92vw);
  max-height: 80vh;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18);
  display: flex;
  flex-direction: column;
}

.dialog-title {
  font-size: 18px;
  font-weight: 700;
  color: #1f2d3d;
  margin-bottom: 12px;
}

.log-box {
  flex: 1;
  min-height: 360px;
  max-height: 56vh;
  overflow: auto;
  padding: 14px;
  background: #0f172a;
  color: #e5e7eb;
  border-radius: 8px;
  font-size: 13px;
  line-height: 1.65;
  white-space: pre-wrap;
  word-break: break-word;
}

.dialog-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

@media (max-width: 900px) {
  .form-grid {
    grid-template-columns: 1fr;
  }

  .content-area {
    padding: 14px;
  }
}
</style>
