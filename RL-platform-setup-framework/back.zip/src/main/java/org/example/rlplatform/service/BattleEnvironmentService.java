package org.example.rlplatform.service;

import org.example.rlplatform.entity.BattleEnvironment;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface BattleEnvironmentService {

    BattleEnvironment create(String name,
                             String code,
                             Boolean isGpu,
                             String cudaDevice,
                             MultipartFile requirements,
                             MultipartFile script);

    List<BattleEnvironment> listAll();

    List<BattleEnvironment> listReadyBattleEnvironments();

    BattleEnvironment getReadyByCode(String code);

    String resolveWorkspace(String code);

    void disable(Integer id);

    void delete(Integer id);
}