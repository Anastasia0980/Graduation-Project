package org.example.rlplatform.service.impl;

import org.example.rlplatform.Repository.BattleEnvironmentRepository;
import org.example.rlplatform.entity.BattleEnvironment;
import org.example.rlplatform.service.BattleEnvironmentService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.Executor;

@Service
public class BattleEnvironmentServiceImpl implements BattleEnvironmentService {

    private static final DateTimeFormatter NAME_TIME = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final BattleEnvironmentRepository battleEnvironmentRepository;
    private final Executor evaluationExecutor;

    @Value("${conda.executable:conda}")
    private String condaExecutable;

    @Value("${conda.envs-root:}")
    private String condaEnvsRoot;

    @Value("${battle-env.root:}")
    private String battleEnvRoot;

    @Value("${battle-env.python-version:3.9}")
    private String battleEnvPythonVersion;

    @Value("${evaluation.workspace:}")
    private String defaultWorkspace;

    public BattleEnvironmentServiceImpl(BattleEnvironmentRepository battleEnvironmentRepository,
                                        @Qualifier("evaluationExecutor") Executor evaluationExecutor) {
        this.battleEnvironmentRepository = battleEnvironmentRepository;
        this.evaluationExecutor = evaluationExecutor;
    }

    @Override
    public BattleEnvironment create(String name,
                                    String code,
                                    Boolean isGpu,
                                    String cudaDevice,
                                    MultipartFile requirements,
                                    MultipartFile script) {
        if (name == null || name.isBlank()) {
            throw new RuntimeException("环境名称不能为空");
        }
        if (code == null || code.isBlank()) {
            throw new RuntimeException("环境编码不能为空");
        }
        String normalizedCode = normalizeCode(code);
        if (battleEnvironmentRepository.existsByCodeAndIsDeletedFalse(normalizedCode)) {
            throw new RuntimeException("环境编码已存在");
        }
        if (requirements == null || requirements.isEmpty()) {
            throw new RuntimeException("请上传 requirements.txt");
        }
        if (script == null || script.isEmpty()) {
            throw new RuntimeException("请上传对战脚本");
        }
        String scriptName = Objects.requireNonNullElse(script.getOriginalFilename(), "battle.py").toLowerCase(Locale.ROOT);
        if (!scriptName.endsWith(".py")) {
            throw new RuntimeException("对战脚本必须是 .py 文件");
        }

        try {
            Path envRoot = resolveEnvironmentRoot(normalizedCode);
            Files.createDirectories(envRoot);
            Path requirementsPath = envRoot.resolve("requirements.txt");
            Path scriptPath = envRoot.resolve("battle_runner.py");
            requirements.transferTo(requirementsPath);
            script.transferTo(scriptPath);

            BattleEnvironment env = new BattleEnvironment();
            env.setName(name.trim());
            env.setCode(normalizedCode);
            env.setModeType("BATTLE");
            env.setCondaEnvName(buildCondaEnvName(normalizedCode));
            env.setRequirementsPath(requirementsPath.toString());
            env.setScriptPath(scriptPath.toString());
            env.setWorkspacePath(resolveWorkspaceRoot(envRoot).toString());
            env.setStatus("CREATING");
            env.setInstallLog("已接收上传文件，准备创建 Conda 环境...\n");
            env.setIsGpu(Boolean.TRUE.equals(isGpu));
            env.setCudaDevice((cudaDevice == null || cudaDevice.isBlank()) ? null : cudaDevice.trim());
            env.setIsDeleted(false);
            env.setCreateTime(LocalDateTime.now());
            env.setUpdateTime(LocalDateTime.now());
            battleEnvironmentRepository.save(env);

            evaluationExecutor.execute(() -> createCondaEnvironment(env.getId()));
            return env;
        } catch (Exception e) {
            throw new RuntimeException("环境创建初始化失败: " + e.getMessage(), e);
        }
    }

    @Override
    public List<BattleEnvironment> listAll() {
        return battleEnvironmentRepository.findAllByOrderByIdDesc();
    }

    @Override
    public List<BattleEnvironment> listReadyBattleEnvironments() {
        return battleEnvironmentRepository.findByStatusAndIsDeletedFalseOrderByIdDesc("READY");
    }

    @Override
    public BattleEnvironment getReadyByCode(String code) {
        if (code == null || code.isBlank()) {
            return null;
        }
        return battleEnvironmentRepository.findByCodeAndModeTypeAndIsDeletedFalse(code, "BATTLE")
                .filter(item -> "READY".equalsIgnoreCase(item.getStatus()))
                .orElse(null);
    }

    @Override
    public String resolveWorkspace(String code) {
        BattleEnvironment env = getReadyByCode(code);
        if (env != null && env.getWorkspacePath() != null && !env.getWorkspacePath().isBlank()) {
            return env.getWorkspacePath();
        }
        return defaultWorkspace;
    }

    @Override
    public void disable(Integer id) {
        BattleEnvironment env = battleEnvironmentRepository.findByIdAndIsDeletedFalse(id);
        if (env == null) {
            throw new RuntimeException("环境不存在");
        }
        if ("DELETED".equalsIgnoreCase(env.getStatus())) {
            throw new RuntimeException("环境已删除，不能重复停用");
        }
        env.setStatus("DISABLED");
        env.setUpdateTime(LocalDateTime.now());
        appendLog(env, "环境已停用");
        battleEnvironmentRepository.save(env);
    }

    @Override
    public void delete(Integer id) {
        BattleEnvironment env = battleEnvironmentRepository.findByIdAndIsDeletedFalse(id);
        if (env == null) {
            throw new RuntimeException("环境不存在或已删除");
        }
        if ("CREATING".equalsIgnoreCase(env.getStatus())) {
            throw new RuntimeException("环境正在创建中，暂不支持删除");
        }

        String originalCode = env.getCode();
        String deletedCode = buildDeletedCode(originalCode, env.getId());

        StringBuilder log = new StringBuilder();
        if (env.getInstallLog() != null && !env.getInstallLog().isBlank()) {
            log.append(env.getInstallLog());
            if (!env.getInstallLog().endsWith("\n")) {
                log.append('\n');
            }
        }
        log.append("开始删除环境资源...\n");

        try {
            removeCondaEnvironment(env, log);
        } catch (Exception e) {
            log.append("删除 Conda 环境失败: ").append(e.getMessage()).append('\n');
        }

        try {
            deleteUploadedFiles(env, log);
        } catch (Exception e) {
            log.append("删除上传文件失败: ").append(e.getMessage()).append('\n');
        }

        log.append("原环境编码: ").append(originalCode).append('\n');
        log.append("删除后历史编码: ").append(deletedCode).append('\n');

        env.setCode(deletedCode);
        env.setStatus("DELETED");
        env.setPythonPath(null);
        env.setIsDeleted(true);
        env.setInstallLog(log.toString());
        env.setUpdateTime(LocalDateTime.now());
        battleEnvironmentRepository.save(env);
    }

    private void createCondaEnvironment(Integer environmentId) {
        BattleEnvironment env = battleEnvironmentRepository.findByIdAndIsDeletedFalse(environmentId);
        if (env == null) {
            return;
        }
        StringBuilder log = new StringBuilder();
        try {
            Path workspaceRoot = Paths.get(env.getWorkspacePath());
            Files.createDirectories(workspaceRoot);
            log.append("开始创建 Conda 环境: ").append(env.getCondaEnvName()).append('\n');
            runCommand(log, buildCondaCommand("create", "-y", "-n", env.getCondaEnvName(), "python=" + battleEnvPythonVersion), null);
            log.append("开始安装 requirements.txt\n");
            runCommand(log, buildCondaCommand("run", "-n", env.getCondaEnvName(), "python", "-m", "pip", "install", "-r", env.getRequirementsPath()), null);

            Path pythonPath = resolveCondaPythonPath(env.getCondaEnvName());
            env.setPythonPath(pythonPath.toString());
            env.setStatus("READY");
            log.append("环境创建完成\n");
        } catch (Exception e) {
            env.setStatus("FAILED");
            log.append("环境创建失败: ").append(e.getMessage()).append('\n');
        }
        env.setInstallLog(log.toString());
        env.setUpdateTime(LocalDateTime.now());
        battleEnvironmentRepository.save(env);
    }

    private void removeCondaEnvironment(BattleEnvironment env, StringBuilder log) {
        if (env.getCondaEnvName() == null || env.getCondaEnvName().isBlank()) {
            log.append("未检测到 Conda 环境名，跳过删除 Conda 环境\n");
            return;
        }
        log.append("开始删除 Conda 环境: ").append(env.getCondaEnvName()).append('\n');
        runCommand(log, buildCondaCommand("remove", "-y", "-n", env.getCondaEnvName(), "--all"), null);
        log.append("Conda 环境删除完成\n");
    }

    private void deleteUploadedFiles(BattleEnvironment env, StringBuilder log) throws IOException {
        Path envRoot = resolveEnvironmentRoot(env.getCode());

        if (env.getRequirementsPath() != null && !env.getRequirementsPath().isBlank()) {
            deleteFileIfExists(Paths.get(env.getRequirementsPath()), log, "requirements.txt");
        }
        if (env.getScriptPath() != null && !env.getScriptPath().isBlank()) {
            deleteFileIfExists(Paths.get(env.getScriptPath()), log, "对战脚本");
        }

        if (env.getWorkspacePath() != null && !env.getWorkspacePath().isBlank()) {
            Path workspacePath = Paths.get(env.getWorkspacePath());
            if (workspacePath.startsWith(envRoot) && Files.exists(workspacePath)) {
                deleteDirectoryIfExists(workspacePath, log, "环境工作目录");
            } else if (Files.exists(workspacePath)) {
                log.append("工作目录不是该环境独占目录，已跳过删除: ").append(workspacePath).append('\n');
            }
        }

        if (Files.exists(envRoot)) {
            deleteDirectoryIfExists(envRoot, log, "环境根目录");
        }
    }

    private void deleteFileIfExists(Path filePath, StringBuilder log, String label) throws IOException {
        if (Files.exists(filePath)) {
            Files.delete(filePath);
            log.append(label).append("已删除: ").append(filePath).append('\n');
        } else {
            log.append(label).append("不存在，跳过: ").append(filePath).append('\n');
        }
    }

    private void deleteDirectoryIfExists(Path dirPath, StringBuilder log, String label) throws IOException {
        Files.walkFileTree(dirPath, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.deleteIfExists(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.deleteIfExists(dir);
                return FileVisitResult.CONTINUE;
            }
        });
        log.append(label).append("已删除: ").append(dirPath).append('\n');
    }

    private void appendLog(BattleEnvironment env, String message) {
        String oldLog = env.getInstallLog() == null ? "" : env.getInstallLog();
        if (!oldLog.isEmpty() && !oldLog.endsWith("\n")) {
            oldLog = oldLog + "\n";
        }
        env.setInstallLog(oldLog + message + "\n");
    }

    private void runCommand(StringBuilder log, List<String> command, Path workingDir) {
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            if (workingDir != null) {
                pb.directory(workingDir.toFile());
            }
            Process process = pb.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    log.append(line).append('\n');
                }
            }
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new RuntimeException("命令执行失败: " + String.join(" ", command));
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private List<String> buildCondaCommand(String... args) {
        boolean isWindows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        if (isWindows && condaExecutable != null && condaExecutable.toLowerCase(Locale.ROOT).endsWith(".bat")) {
            java.util.ArrayList<String> cmd = new java.util.ArrayList<>();
            cmd.add("cmd");
            cmd.add("/c");
            cmd.add(condaExecutable);
            cmd.addAll(java.util.Arrays.asList(args));
            return cmd;
        }
        java.util.ArrayList<String> cmd = new java.util.ArrayList<>();
        cmd.add(condaExecutable);
        cmd.addAll(java.util.Arrays.asList(args));
        return cmd;
    }

    private Path resolveEnvironmentRoot(String code) {
        String baseDir = (battleEnvRoot == null || battleEnvRoot.isBlank())
                ? Paths.get(System.getProperty("user.dir"), "battle_envs").toString()
                : battleEnvRoot;
        return Paths.get(baseDir, code);
    }

    private Path resolveWorkspaceRoot(Path envRoot) {
        if (defaultWorkspace != null && !defaultWorkspace.isBlank()) {
            return Paths.get(defaultWorkspace);
        }
        return envRoot.resolve("workspace");
    }

    private Path resolveCondaPythonPath(String envName) {
        boolean isWindows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        if (condaEnvsRoot != null && !condaEnvsRoot.isBlank()) {
            return isWindows
                    ? Paths.get(condaEnvsRoot, envName, "python.exe")
                    : Paths.get(condaEnvsRoot, envName, "bin", "python");
        }
        return isWindows
                ? Paths.get(envName, "python.exe")
                : Paths.get(envName, "bin", "python");
    }

    private String buildCondaEnvName(String code) {
        return "rl_battle_" + code + "_" + LocalDateTime.now().format(NAME_TIME);
    }

    private String buildDeletedCode(String originalCode, Integer id) {
        String safeCode = originalCode == null ? "deleted_env" : originalCode.trim();
        return safeCode + "__deleted__" + id + "_" + System.currentTimeMillis();
    }

    private String normalizeCode(String code) {
        return code.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "_");
    }
}