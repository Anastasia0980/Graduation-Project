package org.example.rlplatform.controller;

import org.example.rlplatform.entity.BattleEnvironment;
import org.example.rlplatform.entity.Result;
import org.example.rlplatform.service.BattleEnvironmentService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/battle-environments")
public class BattleEnvironmentController {

    private final BattleEnvironmentService battleEnvironmentService;

    public BattleEnvironmentController(BattleEnvironmentService battleEnvironmentService) {
        this.battleEnvironmentService = battleEnvironmentService;
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public Result<Map<String, Object>> create(@RequestParam("name") String name,
                                              @RequestParam("code") String code,
                                              @RequestParam(value = "isGpu", required = false, defaultValue = "false") Boolean isGpu,
                                              @RequestParam(value = "cudaDevice", required = false) String cudaDevice,
                                              @RequestParam("requirements") MultipartFile requirements,
                                              @RequestParam("script") MultipartFile script) {
        BattleEnvironment env = battleEnvironmentService.create(name, code, isGpu, cudaDevice, requirements, script);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("id", env.getId());
        data.put("code", env.getCode());
        data.put("status", env.getStatus());
        return Result.success(data);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public Result<List<BattleEnvironment>> listAll() {
        return Result.success(battleEnvironmentService.listAll());
    }

    @GetMapping("/ready")
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public Result<List<BattleEnvironment>> listReady() {
        return Result.success(battleEnvironmentService.listReadyBattleEnvironments());
    }

    @PostMapping("/{id}/disable")
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public Result<Void> disable(@PathVariable Integer id) {
        battleEnvironmentService.disable(id);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public Result<Void> delete(@PathVariable Integer id) {
        battleEnvironmentService.delete(id);
        return Result.success();
    }
}