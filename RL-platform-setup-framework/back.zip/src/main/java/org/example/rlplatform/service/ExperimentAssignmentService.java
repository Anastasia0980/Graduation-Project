package org.example.rlplatform.service;

import org.example.rlplatform.entity.ExperimentAssignment;

import org.springframework.data.domain.Page;

import javax.naming.CannotProceedException;

public interface ExperimentAssignmentService {

    Page<ExperimentAssignment> listStuAssignments(Integer pageNum, Integer pageSize);

<<<<<<< HEAD
    ExperimentAssignment create(Integer classId, ExperimentAssignment experimentAssignment);
=======
    Integer create(Integer classId, ExperimentAssignment experimentAssignment);

    void publish(Integer assignmentId);
>>>>>>> origin/integration-test

    ExperimentAssignment update(Integer assignmentId, ExperimentAssignment experimentAssignment);

    Page<ExperimentAssignment> listTeaAssignments(Integer pageNum, Integer pageSize);

    Page<ExperimentAssignment> listAssignmentsByClass(Integer classId, Integer pageNum, Integer pageSize);

    ExperimentAssignment getById(Integer assignmentId);

    void softDelete(Integer assignmentId);
}
